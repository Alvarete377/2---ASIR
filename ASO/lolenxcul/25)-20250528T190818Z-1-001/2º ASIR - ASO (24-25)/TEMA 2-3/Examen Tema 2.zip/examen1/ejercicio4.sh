#! /bin/bash

file=$1

if [[ -f "$file" ]]; then
	echo "El archivo $file existe"
else
	echo "El archivo $file no existe"
fi

while IFS= read -r ip; do
        if ping -c 1 "$ip" &>/dev/null; then
                echo "La direccion IP $ip esta disponible"
        else
                echo "La direccion IP $ip no esta disponible"
	fi
done < ips.txt


