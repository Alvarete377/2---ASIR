#! /bin/bash

usuario=$1

if [[ -z "$usuario" ]]; then
	echo "USO: $# $0"
fi


if ! id "$usuario" &>/dev/null; then
        echo "ERROR: el usuario $usuario no existe"
	exit 1
fi


conectado=$(who | grep "^$usuario" | awk '{print $3, $4, $5}')

if [[ -n "$conectado" ]]; then
        echo "El usuario $usuario lleva conectado en el sistema desde $conectado"
else
        echo "El usuario $usuario no se encuentra conectado al sistema"
fi


