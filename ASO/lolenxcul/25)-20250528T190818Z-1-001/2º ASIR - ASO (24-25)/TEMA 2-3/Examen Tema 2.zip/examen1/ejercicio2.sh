#! /bin/bash

# script que reciba un valor numerico, operador y otro valor numerico

echo "Introduzca el
