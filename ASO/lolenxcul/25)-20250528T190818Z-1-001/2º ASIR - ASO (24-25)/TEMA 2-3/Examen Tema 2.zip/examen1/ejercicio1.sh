#! /bin/bash

echo "Introduzca un numero 1 -> "
read num1

echo "Introduzca un numero 2 -> "
read num2


if [[ "$num1" =~ ^[[:digit:]]+$ ]]; then
  if [[ "$num2" =~ ^[[:digit:]]+$ ]]; then
	if ((num1 > num2)); then
		echo "El primer numero $num1 es mayor que el segundo numero $num2"
	elif ((num1 < num2)); then
		echo "El primer numero $num1 es menor que el segundo numero $num2"
	else
		echo "El primer numero $num1 y el segundo numero $num2 son iguales"
	fi

  else
	echo "El segundo valor introducido b no es un numero"
  fi
else
	echo "El primer valor introducido a no es un numero"
fi
