#!/bin/bash

# Crea un script, de nombre numeraLineas.sh, que recibirá como único argumento el  nombre de un fichero de texto. El script enviará a la salida estándar las líneas del fichero  recibido como argumento, numerándolas de forma ascendente y consecutiva

file=$1

if [[ -z "$file" || ! -f "$file" ]]; then
    echo "USO: $0 <nombre de fichero>"
    exit 1
fi

nl "$file"

