#! /bin/bash

#Crea un script, de nombre ejemplosArgumentos.sh, que reciba un número cualquiera  de argumentos. El script deberá mostrar por pantalla la siguiente información: 
# • Nombre del script. 
# • Número de argumentos recibidos. 
# • Valor de todos los argumentos recibidos

echo "Nombre del fichero: $0"
echo "Numero de argumentos recibidos: $#"
echo "Valores de todos los argumentos: $*"

cont=1

for i in "$0"; do
	echo "Argumento $cont:  $i"
	((cont++))
done
