#!/bin/bash

# Verifica si al menos se pasa un archivo como argumento


if [[ $# -eq 0 ]]; then
    echo "USO: $0 <nombre de fichero(s) regular(es)>"
    exit 1
fi

# Verifica que todos los argumentos sean archivos regulares
for file in "$@"; do
    if [[ ! -f "$file" ]]; then
        echo "ERROR: $file no es un nombre de fichero regular"
        exit 1
    fi
done

# Solicita al usuario la cadena separadora
read -p "Introduzca la cadena que desea usar como separador: " separator

# Concatenar el contenid
 de cada archivo con el separador
for file in "$@"; do
    cat "$file"
    echo -e "\n$separator\n"
done

exit 0

