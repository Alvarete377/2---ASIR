#!/bin/bash

# Crea un script, de nombre pingMultiple.sh, que reciba como único argumento el  nombre de un fichero de texto. Suponiendo que el fichero incluya una dirección ip en  cada línea, el script deberá comprobar si obtiene respuesta al enviarles un comando ping

file=$1

while IFS= read -r ip; do
    if ping -c 1 "$ip" &>/dev/null; then
        echo "La dirección IP $ip responde al ping."
    else
        echo "La dirección IP $ip no responde al ping."
    fi
done < "$file"

