#!/bin/bash

# Modifica el script anterior para que permita introducir las opciones del primer  argumento tanto en mayúsculas como en minúsculas.

option=$1
file=$2

if [[ -z "$option" || -z "$file" ]]; then
    echo "USO: $0 {-u | -p | -l} <nombre de fichero>"
    exit 1
fi

if [[ ! -f "$file" ]]; then
    echo "ERROR: El fichero $file no existe o no es un fichero regular."
    exit 1
fi

case "$option" in
    -u) nano "$file" ;;
    -p) less "$file" ;;
    -l) wc -l < "$file" ;;
    *) echo "ERROR: Opción inválida. Use -u, -p o -l." ;;
esac

