#!/bin/bash

# Modifica el script anterior para que el usuario introduzca el path de un fichero. Este  contendrá los nombres de variables, separadas por ‘:’, que serán comprobadas y  mostradas. Las variables podrán encontrarse en la misma línea o en diferentes

read -p "Introduzca el path del fichero con los nombres de las variables: " file_path

if [[ ! -f "$file_path" ]]; then
    echo "ERROR: El fichero $file_path no existe."
    exit 1
fi

while IFS=':' read -r -a vars; do
    for var_name in "${vars[@]}"; do
        if [[ -n "${!var_name}" ]]; then
            echo "La variable $var_name existe con el valor ${!var_name}"
        else
            echo "La variable $var_name no existe"
        fi
    done
done < "$file_path"

