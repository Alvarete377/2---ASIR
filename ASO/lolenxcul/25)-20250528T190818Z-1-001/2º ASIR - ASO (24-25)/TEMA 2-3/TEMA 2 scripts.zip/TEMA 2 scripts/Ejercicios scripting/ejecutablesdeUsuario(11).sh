#!/bin/bash

# Crea un script, de nombre ejecutablesDeUsuario.sh, que comprobará si el usuario que  ejecuta el script tiene un directorio llamado “ejecutables” en su directorio casa. Solo en  caso de que el usuario no disponga de este directorio, el script procederá a crearlo, y  añadirá, de forma persistente, al valor de la variable PATH la ruta absoluta del nuevo  directorio. De esta forma, el usuario podrá colocar en su directorio “ejecutables” los  programas que quiera ejecutar desde cualquier ubicación, sin necesidad de tener que  teclear su ruta absoluta o relativa.


directorio="$HOME/ejecutables"

if [[ ! -d "$directorio" ]]; then
    mkdir "$directorio"
    echo "Directorio '$directorio' creado."
    
    echo "Añadiendo '$directorio' al PATH de manera persistente."
    
    if ! grep -q "$directorio" "$HOME/.bashrc"; then
        echo "export PATH=\$PATH:$directorio" >> "$HOME/.bashrc"
        echo "Ruta '$directorio' añadida al PATH en .bashrc."
    else
        echo "La ruta '$directorio' ya está en el PATH."
    fi
else
    echo "El directorio '$directorio' ya existe."
fi

