#!/bin/bash

# Modifica el script anterior para que: 
# • Antes de realizar la copia, compruebe si el fichero recibido como argumento existe  realmente. En caso de que no exista mostrar el mensaje “ERROR: El fichero <path  del fichero> no existe”. 
# • Debe comprobar el valor de retorno del comando empleado para hacer la copia.  En función de valor del retorno, el script enviará a la salida estándar el mensaje  “Copia realizada correctamente” o “Se detecto un error durante la copia

file_path=$1
user_dir="/tmp/$(whoami)"

if [[ ! -f "$file_path" ]]; then
    echo "ERROR: El fichero $file_path no existe."
    exit 1
fi

mkdir -p "$user_dir"

dest_file="$user_dir/$(basename "$file_path")"
if [[ -e "$dest_file" ]]; then
    echo "El archivo ya existe en el directorio compartido y no será sobrescrito."
else
    cp "$file_path" "$dest_file"
    if [[ $? -eq 0 ]]; then
        echo "Copia realizada correctamente"
    else
        echo "Se detectó un error durante la copia"
    fi
fi

