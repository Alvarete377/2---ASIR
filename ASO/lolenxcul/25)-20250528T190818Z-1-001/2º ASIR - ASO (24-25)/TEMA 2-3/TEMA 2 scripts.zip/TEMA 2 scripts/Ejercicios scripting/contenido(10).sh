#!/bin/bash

# Modifica el script anterior para que compruebe si ha recibido el argumento necesario.  En caso de no recibir argumento, mostrará el mensaje: “USO: <nombre del script>  <nombre de fichero o directorio>” y terminará su ejecución devolviendo un 1. En caso  contrario, un 0.


if [[ -z "$1" ]]; then
    echo "USO: $(basename "$0")"
    exit 1
fi

input=$1

if [[ -f "$input" ]]; then
    less "$input"
elif [[ -d "$input" ]]; then
    ls -l "$input"
else
    echo "ERROR: $input no es un fichero ni un directorio válido."
    exit 1
fi

