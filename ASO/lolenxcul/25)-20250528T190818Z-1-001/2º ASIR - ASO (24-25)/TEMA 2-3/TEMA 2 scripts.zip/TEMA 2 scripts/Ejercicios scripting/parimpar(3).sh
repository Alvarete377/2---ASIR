#! /bin/bash

# Crea un script, de nombre parimpar.sh, que solicitará un número al usuario, mediante  la entrada estándar, y comprobará si el número es par o impar

echo "Introduce un valor"
read num1

if [[ "$num1" =~ ^[[:digit:]]+$ ]]; then
	if ((num1 % 2 == 0)); then 
		echo "El numero $num1 es par"
	else
		echo "El numer $num1 es impar"
	fi 
else
	echo "El numero no es valido"
fi
