#!/bin/bash

# Crea un script, de nombre usuariosConectados.sh, que reciba como parámetro un  nombre de usuario y escriba por pantalla si el usuario se encuentra conectado al sistema y desde cuándo. Deberá comprobar primeramente si el usuario existe en el sistema.

usuario=$1

if ! id "$usuario" &>/dev/null; then
    echo "ERROR: El usuario '$usuario' no existe en el sistema."
    exit 1
fi

conectado=$(who | grep "^$usuario" | awk '{print $3, $4, $5}')

if [[ -n "$conectado" ]]; then
    echo "El usuario '$usuario' está conectado desde: $conectado"
else
    echo "El usuario '$usuario' no está conectado en este momento."
fi

