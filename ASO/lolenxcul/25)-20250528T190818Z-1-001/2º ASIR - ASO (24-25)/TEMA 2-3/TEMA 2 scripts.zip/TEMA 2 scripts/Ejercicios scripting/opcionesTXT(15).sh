#!/bin/bash

# Modifica el anterior script para que, justo antes de editar el fichero, compruebe si el  usuario tiene permiso de lectura y escritura

option=${1,,}
file=$2

if [[ -z "$option" || -z "$file" ]]; then
    echo "USO: $0 {-u | -p | -l} <nombre de fichero>"
    exit 1
fi

if [[ ! -f "$file" ]]; then
    echo "ERROR: El fichero $file no existe o no es un fichero regular."
    exit 1
fi

case "$option" in
    -u) 
        if [[ -r "$file" && -w "$file" ]]; then
            nano "$file"
        else
            echo "ERROR: No tiene permisos de lectura y escritura en $file."
        fi
        ;;
    -p) less "$file" ;;
    -l) wc -l < "$file" ;;
    *) echo "ERROR: Opción inválida. Use -u, -p o -l." ;;
esac

