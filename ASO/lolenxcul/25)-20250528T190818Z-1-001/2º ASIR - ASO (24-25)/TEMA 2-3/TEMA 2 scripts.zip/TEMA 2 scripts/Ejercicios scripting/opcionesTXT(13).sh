#!/bin/bash

# Crea un script, de nombre opcionesTXT.sh, que reciba dos argumentos obligatorios.  El primero consistirá en una opción de entre las siguientes: -u, -p y -l. El segundo será el  nombre de un fichero regular. Según el valor recibido en el primer argumento, el script  editará, paginará o mostrará el número de líneas del fichero recibido como segundo  parámetro. Con respecto a las comprobaciones, el script deberá asegurarse que las  opciones son adecuadas y que el fichero es un fichero y que existe


option=$1
file=$2

if [[ -z "$option" || -z "$file" ]]; then
    echo "USO: $0 {-u | -p | -l} <nombre de fichero>"
    exit 1
fi

if [[ ! -f "$file" ]]; then
    echo "ERROR: El fichero $file no existe o no es un fichero regular."
    exit 1
fi

case "$option" in
    -u) nano "$file" ;;
    -p) less "$file" ;;
    -l) wc -l < "$file" ;;
    *) echo "ERROR: Opción inválida. Use -u, -p o -l." ;;
esac

