#! /bin/bash

# Modifica el script anterior para que, además de comprobar la existencia, muestre por  pantalla el valor de la variable solicitada

read -p "Introduzca el nombre: " var_name

if [[ ! -z "$var_name" ]]; then
        if [[ -n "${!var_name}" ]]; then 
                echo "La variable $var_name existe con el valor ${!var_name}"
        else
                echo "La variable $var_name no existe"
        fi
else
        echo "El valor introducido no es valido"
fi
