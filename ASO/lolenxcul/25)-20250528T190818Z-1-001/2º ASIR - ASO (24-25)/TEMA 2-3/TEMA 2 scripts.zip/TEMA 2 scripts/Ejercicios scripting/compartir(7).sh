#!/bin/bash

# Crea un script, de nombre compartir.sh, que sirva para copiar ficheros en un directorio  compartido. Recibirá como parámetro de entrada el path de un fichero y realizará una  copia en /tmp/<login usuario>. Además de lo anterior, deberá prestar especial atención a  no sobreescribir ficheros ya compartidos por el usuario. El script creará el directorio si no  existiera.

file_path=$1
user_dir="/tmp/$(whoami)"

if [[ ! -f "$file_path" ]]; then
    echo "ERROR: El fichero $file_path no existe."
    exit 1
fi

mkdir -p "$user_dir"

dest_file="$user_dir/$(basename "$file_path")"
if [[ -e "$dest_file" ]]; then
    echo "El archivo ya existe en el directorio compartido y no será sobrescrito."
else
    cp "$file_path" "$dest_file" && echo "Archivo copiado en $user_dir."
fi

