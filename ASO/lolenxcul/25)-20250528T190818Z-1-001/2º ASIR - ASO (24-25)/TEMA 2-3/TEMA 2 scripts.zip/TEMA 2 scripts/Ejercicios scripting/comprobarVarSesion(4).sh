#! /bin/bash

# Crea un script, de nombre comprobarVarSesion.sh, que preguntará al usuario, mediante  la entrada estándar, el nombre de una variable de entorno

read -p "Introduzca el nombre: " var_name

if [[ ! -z "$var_name" ]]; then
	if [[ -n "${!var_name}" ]]; then 
		echo "La variable $var_name existe"
	else
		echo "La variable $var_name no existe"
	fi
else
	echo "El valor introducido no es valido"
fi
