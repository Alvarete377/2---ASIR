#!/bin/bash

# Crea un script, de nombre usuariosLocales.sh, que recorra el fichero /etc/passwd y  muestre el nombre de usuario con su UID. El UID deberá ser mayor o igual a 1000

while IFS=: read -r username _ uid _; do
    if (( uid >= 1000 )); then
        echo "Usuario: $username, UID: $uid"
    fi
done < /etc/passwd

