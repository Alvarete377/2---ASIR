#! /bin/bash

# Crea un script, de nombre comparador.sh, que reciba dos números por la entrada  estándar y los compare. Tras compararlos enviará a la salida estándar un mensaje del tipo  “El primer número (…) es mayor que el segundo número (…)”, “El primer número (…)  es menor que el segundo número (…)” o “El primer número (…) es igual que el segundo  número (…)”. Comprobar el funcionamiento introduciendo los números a través del  teclado

echo "Introduce el primer numero: "
read num1


echo "Introduce el segundo numero: "
read num2

if [[ "$num1" =~ ^[[:digit:]]+$ ]]; then
    if [[ "$num2" =~ ^[[:digit:]]+$ ]]; then

        if ((num1 > num2)); then
            echo "El primer número ($num1) es mayor que el segundo número ($num2)"
        elif ((num1 < num2)); then
            echo "El primer número ($num1) es menor que el segundo número ($num2)"
        else
            echo "El primer número ($num1) es igual que el segundo número ($num2)"
        fi
    else
	echo  "El segundo valor no es un numero valido"
    fi
else
	echo "El primer valor no es un numero valido"
fi


