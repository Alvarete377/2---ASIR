#!/bin/bash

# Crea un script, de nombre contenido.sh, que reciba un único argumento. Si el valor  recibido es un nombre de fichero existente, deberá paginar su contenido. En cambio, si el  valor recibido es un nombre de directorio, deberá listar su contenido

entrada="$1"

if [[ -f "$entrada" ]]; then
    less "$entrada"
elif [[ -d "$entrada" ]]; then
    ls -l "$entrada"
else
    echo "ERROR: $entrada no es un fichero ni un directorio válido"
    exit 1
fi






