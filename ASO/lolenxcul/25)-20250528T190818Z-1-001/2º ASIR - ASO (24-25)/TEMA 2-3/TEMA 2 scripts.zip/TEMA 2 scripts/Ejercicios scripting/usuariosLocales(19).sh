#!/bin/bash

# Modifica el anterior script para que compruebe a qué usuarios locales del sistema se  le ha creado directorio casa

while IFS=: read -r username _ uid _ home_dir; do
    if (( uid >= 1000 )); then
        if [[ -d "$home_dir" ]]; then
            echo "Usuario: $username, UID: $uid, Directorio casa: $home_dir"
        else
            echo "Usuario: $username, UID: $uid, sin directorio casa"
        fi
    fi
done < /etc/passwd

