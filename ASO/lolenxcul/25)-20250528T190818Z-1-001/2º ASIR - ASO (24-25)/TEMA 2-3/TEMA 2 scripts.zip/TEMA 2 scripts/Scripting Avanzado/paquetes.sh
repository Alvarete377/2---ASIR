#!/bin/bash

# Crea un script, de nombre paquetes.sh, que realice la gestión de la paquetería del
# sistema. El script, además del nombre del paquete como segundo parámetro, recibirá
# como primer parámetro la opción instalar, reinstalar, borrar, purgar, buscar, instalado,
# actualizable o dependencias. Recuerda añadir la gestión de errores (valores nulos,
# acciones permitidas, paquetes disponibles en el sistema, etc.) y la salida de mensajes,
# mediante el elemento logger, en el log del sistema.


if [[ $# -lt 2 ]]; then
    echo "Uso: $0 [instalar|reinstalar|borrar|purgar|buscar|instalado|actualizable|dependencias] nombre_paquete"
    exit 1
fi


accion=$1
paquete=$2


case "$accion" in
    instalar)
        sudo apt install "$paquete" && logger "$paquete instalado correctamente" || logger "Error al instalar $paquete"
        ;;
    reinstalar)
        sudo apt reinstall "$paquete" && logger "$paquete reinstalado correctamente" || logger "Error al reinstalar $paquete"
        ;;
    borrar)
        sudo apt remove "$paquete" && logger "$paquete eliminado correctamente" || logger "Error al eliminar $paquete"
        ;;
    purgar)
        sudo apt purge "$paquete" && logger "$paquete purgado correctamente" || logger "Error al purgar $paquete"
        ;;
    buscar)
        apt search "$paquete"
        ;;
    instalado)
        dpkg -l | grep "^ii" | grep "$paquete" && echo "$paquete está instalado" || echo "$paquete no está instalado"
        ;;
    actualizable)
        apt list --upgradable | grep "$paquete" && echo "$paquete tiene actualizaciones" || echo "$paquete está actualizado"
        ;;
    dependencias)
        apt-cache depends "$paquete"
        ;;
    *)
        echo "Opción no válida: $accion"
        exit 1
        ;;
esac
