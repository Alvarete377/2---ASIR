#!/bin/bash

if [[ $# -lt 2 ]]; then
    echo "Uso: $0 [compus|compgr|agregaus|borraus|agregar|borragr|agregausgr|borrausgr] nombre_usuario/nombre_grupo"
    exit 1
fi

accion=$1
nombre=$2

case "$accion" in
    compus)
        if id "$nombre" &>/dev/null; then
            echo "El usuario '$nombre' existe en el sistema"
        else
            echo "El usuario '$nombre' no existe en el sistema"
        fi
        ;;
    compgr)
        if getent group "$nombre" &>/dev/null; then
            echo "El grupo '$nombre' existe en el sistema"
        else
            echo "El grupo '$nombre' no existe en el sistema"
        fi
        ;;
    agregaus)
        sudo useradd "$nombre" && logger "Usuario '$nombre' agregado" || logger "Error al agregar usuario '$nombre'"
        ;;
    borraus)
        sudo userdel "$nombre" && logger "Usuario '$nombre' eliminado" || logger "Error al eliminar usuario '$nombre'"
        ;;
    agregar)
        sudo groupadd "$nombre" && logger "Grupo '$nombre' agregado" || logger "Error al agregar grupo '$nombre'"
        ;;
    borragr)
        sudo groupdel "$nombre" && logger "Grupo '$nombre' eliminado" || logger "Error al eliminar grupo '$nombre'"
        ;;
    agregausgr)
        if [[ $# -lt 3 ]]; then
            echo "Uso: $0 agregausgr nombre_usuario nombre_grupo"
            exit 1
        fi
        usuario=$2
        grupo=$3
        sudo usermod -aG "$grupo" "$usuario" && logger "Usuario '$usuario' agregado al grupo '$grupo'" || logger "Error al agregar usuario '$usuario' al grupo '$grupo'"
        ;;
    borrausgr)
        if [[ $# -lt 3 ]]; then
            echo "Uso: $0 borrausgr nombre_usuario nombre_grupo"
            exit 1
        fi
        usuario=$2
        grupo=$3
        if id -nG "$usuario" | grep -qw "$grupo"; then
            sudo gpasswd -d "$usuario" "$grupo" && logger "Usuario '$usuario' eliminado del grupo '$grupo'" || logger "Error al eliminar usuario '$usuario' del grupo '$grupo'"
        else
            echo "El usuario '$usuario' no pertenece al grupo '$grupo'"
        fi
        ;;
    *)
        echo "Opción no válida: $accion"
        exit 1
        ;;
esac

