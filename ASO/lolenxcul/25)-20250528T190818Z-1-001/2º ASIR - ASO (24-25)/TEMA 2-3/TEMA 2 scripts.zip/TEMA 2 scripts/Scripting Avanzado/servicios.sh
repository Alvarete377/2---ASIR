#!/bin/bash

if [[ $# -lt 2 ]]; then
    echo "Uso: $0 [arranca|para|reinicia|recarga|habilita|deshabilita|estado] nombre_servicio"
    exit 1
fi

accion=$1
servicio=$2

case "$accion" in
    arranca)
        sudo systemctl start "$servicio.service" && logger "$servicio iniciado" || logger "Error al iniciar $servicio"
        ;;
    para)
        sudo systemctl stop "$servicio.service" && logger "$servicio detenido" || logger "Error al detener $servicio"
        ;;
    reinicia)
        sudo systemctl restart "$servicio.service" && logger "$servicio reiniciado" || logger "Error al reiniciar $servicio"
        ;;
    recarga)
        sudo systemctl reload "$servicio.service" && logger "$servicio recargado" || logger "Error al recargar $servicio"
        ;;
    habilita)
        sudo systemctl enable "$servicio.service" && logger "$servicio habilitado" || logger "Error al habilitar $servicio"
        ;;
    deshabilita)
        sudo systemctl disable "$servicio.service" && logger "$servicio deshabilitado" || logger "Error al deshabilitar $servicio"
        ;;
    estado)
        sudo systemctl status "$servicio.service"
        ;;
    *)
        echo "Opción no válida: $accion"
        exit 1
        ;;
esac

