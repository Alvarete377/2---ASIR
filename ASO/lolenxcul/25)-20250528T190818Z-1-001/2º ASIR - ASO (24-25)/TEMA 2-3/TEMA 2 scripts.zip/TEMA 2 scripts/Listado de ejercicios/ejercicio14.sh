#!/bin/bash

# Cambiar el separador de campos a ':'
IFS=':'

# Leer 5 palabras separadas por ':'
echo "Introduce 5 palabras separadas por ':':"
read palabra1 palabra2 palabra3 palabra4 palabra5

# Mostrar las palabras ingresadas
echo "Las palabras ingresadas son:"
echo "$palabra1:$palabra2:$palabra3:$palabra4:$palabra5"

