EJERCICIO 13

SCRIPT 1:

#!/bin/bash

read -t 5 -sp "Introduzca un valor dentro de 5 segundos: " Pepe
echo -e "\nValor introducido: $valor"


read -p "Introduzca su nombre: " Juan
echo "Su nombre es $nombre"


SCRIPT 2:

#!/bin/bash

echo -e "\nIntroduzca el valor o edite el valor por defecto:"
read -ei "valor_por_defecto" variable2
echo "El valor final es: $variable2"


-t Define un tiempo límite en segundos para que el usuario introduzca una entrada. Si el tiempo se agota antes de que el usuario introduzca algo, el comando read terminará.

-s Esconde la entrada del usuario (no muestra lo que se escribe)

-p Muestra un mensaje antes de leer la entrada del usuario

-i Proporciona un valor por defecto editable para el usuario cuando usa el read (solo disponible si se usa con -e)

-e Permite editar la línea de entrada usando teclas de edición como Tab para autocompletar, Flechas para moverse




EJERCICIO 14

echo "variables"
IFS ':'
read 




EJERCICIO 15

echo "Introduzca el nombre del usuario"
read usuario
linea=$(grep -E “^$usuario;. “$” /etc/passwd”

IFS ':'
read us uid gid resto <<<< $linea

echo "US: $us, UID: $uid, GID: $gid"




EJERCICIO 16

echo "Introduzca el nombre del usuario"
read usuario
linea=$(grep -E “^$usuario;. “$” /etc/passwd”

IFS ':'
read us uid gid resto <<<< $linea

echo "US: $us, UID: $uid, GID: $gid"





EJERCICIO 17

if [ -e $1 ]; then
	if [ -f $1 ]; then
		echo "$1 es un fichero"
	fi
	if [ -d $1 ]; then
		echo "$1 es un directorio" 
	fi
	if [ -r $1 ]; then
		echo "$1 tiene permiso de lectura"
	fi
	if [ -w $1 ]; then
		echo "$1 tiene permiso de escritura"  
	fi
	if [ -x $1 ]; then
		echo "$1 tiene permiso de ejecucion" 
else
	echo "$1 no existe"
fi




EJERCICIO 18

#!/bin/bash

echo "Introduce la primera cadena de texto:"
read -p cadena1

echo "Introduce la segunda cadena de texto:"
read -p cadena2

if [ -n $cadena1]; then
    echo "Ambas cadenas tienen contenido"

fi
if [ -n $cadena2]; then
    echo "Ambas cadenas tienen contenido"

fi    
if [ "$cadena1" == "$cadena2" ]; then
       echo "Las cadenas son iguales"
else
       echo "Las cadenas son distintas"

fi        
if [ "$cadena1" < "$cadena2" ]; then
       echo "La primera cadena está antes que la segunda en orden lexicográfico"
else
       echo "La primera cadena está después que la segunda en orden lexicográfico"
fi
else
    echo "Una o ambas cadenas están vacías"
fi




EJERCICIO 19

#!/bin/bash

read -p "Introduce la primera cadena de texto: " cadena1
read -p "Introduce la segunda cadena de texto: " cadena2

if test -n "$cadena1"; then
    echo "La primera cadena tiene contenido: $cadena1"
else
    echo "La primera cadena está vacía"
fi

if test -n "$cadena2"; then
    echo "La segunda cadena tiene contenido: $cadena2"
else
    echo "La segunda cadena está vacía"
fi

if test -n "$cadena1" && test -n "$cadena2"; then
    echo "Ambas cadenas tienen contenido"
    
    if test "$cadena1" = "$cadena2"; then
        echo "Las cadenas son iguales"
    else
        echo "Las cadenas son distintas"

        if test "$cadena1" \< "$cadena2"; then
            echo "La primera cadena está antes que la segunda en orden lexicográfico"
        else
            echo "La primera cadena está después que la segunda en orden lexicográfico"
        fi
    fi
else
    echo "Una o ambas cadenas están vacías"
fi




EJERCICIO 20

#!/bin/bash

numero1=$1
numero2=$2

if [ -z "$numero1" ] || [ -z "$numero2" ]; then
    echo "Por favor, introduce dos números como parámetros."
    exit 1
fi

if [ "$numero1" -gt "$numero2" ]; then
    echo "$numero1 es mayor que $numero2"
elif [ "$numero1" -lt "$numero2" ]; then
    echo "$numero2 es mayor que $numero1"
else
    echo "Ambos números son iguales"
fi

if [ $((numero1 % 2)) -eq 0 ]; then
    echo "$numero1 es par"
else
    echo "$numero1 es impar"
fi



EJERCICIO 21:

#!/bin/bash

if [ \( $numero -gt 0 \) -a \( $numero -lt 11 \) ]; then
    echo "El número $numero está en el rango de 1 a 10."
else
    echo "El número $numero no está en el rango de 1 a 10."
fi


EJERCICIO 22:

#!/bin/bash

if [[ ! ( $numero > 0 && $numero < 11 ) ]]; then
    echo "El número $numero no está en el rango de 1 a 10."
else
    echo "El número $numero está en el rango de 1 a 10."
fi



EJERCICIO 23:

#!/bin/bash

read -n 1 -p "Introduce una opcion 1-4: " opcion
echo

case $opcion in
    1)
        echo "Opción 1 seleccionada."
        ;;
    2)
        echo "Opción 2 seleccionada."
        ;;
    3)
        echo "Opción 3 seleccionada."
        ;;
    4)
        echo "Opción 4 seleccionada."
        ;;
    *)
        echo "Opción inválida. Por favor, introduce un dígito entre 1 y 4."
        ;;
esac



EJERCICIO 24:








EJERCICIO 26:

contador=0

while[contador









EJERCICIO 28:

fichero="/etc/passwd"

while IFS=: read user pw uid gid name home shell; do

	if [$uid -ge 1000 ]; then
		if [ -e $home ]; then
			echo "El usuario $user:$uid tiene su directorio casa $home"
		else
			echo "El usuario $user:$uid no tiene su directorio casa $home"
		fi	
	fi
done < $fichero




EJERCICIO 29:

fichero="/etc/passwd"

while read linea; do
	IFS=':' 
	read -n campos <<< $linea
	
	if [$uid -ge 1000 ]; then
		if [ -e $home ]; then
			echo "El usuario $user:$uid tiene su directorio casa $home"
		else
			echo "El usuario $user:$uid no tiene su directorio casa $home"
		fi	
	fi
done < $fichero















