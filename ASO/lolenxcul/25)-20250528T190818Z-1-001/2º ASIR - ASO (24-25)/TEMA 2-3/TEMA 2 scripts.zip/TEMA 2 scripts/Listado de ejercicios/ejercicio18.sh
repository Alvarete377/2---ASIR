#!/bin/bash

echo "Introduce la primera cadena de texto:"
read -p cadena1

echo "Introduce la segunda cadena de texto:"
read -p cadena2

if [ -n "$cadena1"]; then
    echo "Ambas cadenas tienen contenido"

fi
if [ -n "$cadena2"]; then
    echo "Ambas cadenas tienen contenido"

fi
if [ "$cadena1" == "$cadena2" ]; then
       echo "Las cadenas son iguales"
else
       echo "Las cadenas son distintas"

f
if [ "$cadena1" < "$cadena2" ]; then
       echo "La primera cadena está antes que la segunda en orden lexicográfico"
else
       echo "La primera cadena está después que la segunda en orden lexicográfico"
fi
else
    echo "Una o ambas cadenas están vacías"
fi
