#!/bin/bash

echo -e "\nIntroduzca el valor o edite el valor por defecto:"
read -ei "valor_por_defecto" variable2
echo "El valor final es: $variable2"
