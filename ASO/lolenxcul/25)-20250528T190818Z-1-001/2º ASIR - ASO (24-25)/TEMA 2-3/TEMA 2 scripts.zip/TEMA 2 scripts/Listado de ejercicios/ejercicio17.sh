#!/bin/bash

# Verificar si se ha proporcionado un argumento
if [ -e "$1" ]; then
    if [ -f "$1" ]; then
        echo "$1 es un fichero"
    fi
    if [ -d "$1" ]; then
        echo "$1 es un directorio"
    fi
    if [ -r "$1" ]; then
        echo "$1 tiene permiso de lectura"
    fi
    if [ -w "$1" ]; then
        echo "$1 tiene permiso de escritura"
    fi
    if [ -x "$1" ]; then
        echo "$1 tiene permiso de ejecución"
    fi
else
    echo "$1 no existe"
fi

