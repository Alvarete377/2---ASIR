#!/bin/bash

numero1=$1
numero2=$2

if [ -z "$numero1" ] || [ -z "$numero2" ]; then
    echo "Por favor, introduce dos números como parámetros."
    exit 1
fi

if [ "$numero1" -gt "$numero2" ]; then
    echo "$numero1 es mayor que $numero2"
elif [ "$numero1" -lt "$numero2" ]; then
    echo "$numero2 es mayor que $numero1"
else
    echo "Ambos números son iguales"
fi

if [ $((numero1 % 2)) -eq 0 ]; then
    echo "$numero1 es par"
else
    echo "$numero1 es impar"
fi
