#!bin/bash

echo "Introduzca el nombre del usuario"
read usuario
linea=$(grep -E "^$usuario:" /etc/passwd)

IFS=':'

read us uid gid resto <<< "$linea"

echo "US: $us, UID: $uid, GID: $gid"
