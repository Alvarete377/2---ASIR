#!/bin/bash

read -t 5 -sp "Introduzca un valor dentro de 5 segundos: " valor
echo -e "\nValor introducido: $valor"


read -p "Introduzca su nombre: " nombre
echo "Su nombre es $nombre"
